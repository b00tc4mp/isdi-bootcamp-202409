function Header(){
    return <header>
         <h1>Unsocial</h1>
    </header>
    
}

export default Header